
  <?php

  $offerId = 'S554061791_GB';
  // include PHP SDK
  include_once('cleeng/cleeng_api.php');
  $cleengApi = new Cleeng_Api();
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <script type="text/javascript">
  	    CleengApi.trackOfferImpression("<?php echo $offerId ?>");
  	    function cleengPurchase() {
  		CleengApi.purchase("<?php echo $offerId ?>", function (result) {

  		    window.location.reload();
  		});
  	    }
  	</script>
  <title>Doma&#263;i filmovi online</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="cssNew/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>

  <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-89022952-1', 'auto');
  ga('send', 'pageview');

</script>


<style>
/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 2; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    background-color: rgba(51, 51, 51, 0.57);
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 60%;
}

/* The Close Button */
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
</style>

<style>


    .player-wrapper {
      width:        90%;
      margin-right: auto;
      margin-left:  auto;
      box-shadow:   0 0 30px rgba(0,0,0,0.7);
    }

  </style>





<style>
  /* Add a gray background color and some padding to the footer */
  footer {
    background-color: #f2f2f2;
    padding: 25px;
  }

  .carousel-inner img {
    width: 100%; /* Set width to 100% */
    min-height: 200px;
  }

  /* Hide the carousel text when the screen is less than 600 pixels wide */
  @media (max-width: 600px) {
    .carousel-caption {
      display: none;
    }
  }
</style>

<style>
.wp-caption {
position: relative;
padding: 0;
margin: 0;
opacity: 1;
}
.wp-caption img {
display: block;
max-width: 100%;
height: auto;
}
.wp-caption-text {
opacity: 1;
position: absolute;
width: 100%;
color: #780000;
left: 0;
bottom: 0;
padding: 0.1em 1em;
font-weight: 250;
z-index: 2;
-webkit-box-sizing: border-box;
box-sizing: border-box;
background-color: rgba(255,255,255,1);
-webkit-transition: opacity .3s ease-in-out;
transition: opacity .3s ease-in-out;

}
.wp-caption:hover .wp-caption-text {
opacity: 1;

}

.wp-caption:hover .wp-caption-text a:link {
color: #780000;
/*text-decoration: none;*/

}

.wp-caption-text a {
color: #780000;
/*text-decoration: none;*/

}

.button {
  background-color: #780000; /* Green */
  border: none;
  color: white;
  padding: 5px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}

</style>
<style>
.wp-caption1 {
position: relative;
padding: 0;
margin: 0;
}
.wp-caption1 img {
display: block;
max-width: 100%;
height: auto;
}
.wp-caption1:after {
content: "";
position: absolute;
display: block;
left: 0;
top: 0;
width: 100%;
height: 100%;
/*background: rgba(0, 0, 0, 0) linear-gradient(to bottom, rgba(0, 0, 0, 0) 0px, rgba(0, 0, 0, 0.6) 100%) repeat 0 0;*/
z-index: 1;
}
.wp-caption-text1 {

display: block;
position: absolute;
right: 15%;

left: 10%;
width: 100%;
color: #fff;
left: 0;
bottom: 0;
padding: 1em;
font-weight: 400;

text-transform: uppercase;
z-index: 2;
padding-top: 2px;

-webkit-box-sizing: border-box;
box-sizing: border-box;
text-align: left;
text-shadow: 0 1px 2px rgba(0, 0, 0, .6);
font-size: 22px;
text-transform: uppercase;
font-family: Arial, sans-serif

}

.wp-caption-text1 a {
color: #fff;



}

.titleCosa a {
  color: #780000;
  text-decoration: none;

  font-size: 14px
}

</style>

</head>
<body>
  <?php

  // Check if visitor has access to protected content
  if ($cleengApi->isAccessGranted($offerId)): ?>


  <div id="fb-root"></div>
  <script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.8";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));</script>


  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand>img" href="#"><img src="logoNew.png"></a>

      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">

        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href="pages/zabavnik.html"><span class="#"></span> Zabavnik</a></li>
          <li><a href="pages/CosinoCose.html"><span class="#"></span>&#262;osino &#263;o&#353;e</a></li>


          <li><a href="#"><span class="#"></span> </a></li>
          <li><a href="#"><span class="#"></span> </a></li>
          <li><a href="#"><span class="#"></span> </a></li>
          <li><a href="#"><span class="#"></span> </a></li>
          <li><a href="#"><span class="#"></span> </a></li>

            <li><a href="pages/onama.html"><span class="#"></span> O nama</a></li>
            <li><a href="pages/kontakt.html"><span class="#"></span>Kontakt</a></li>
            <li><a href="pages/uslovi.html"><span class="#"></span> Uslovi kori&#353;&#263;enja</a></li>
            <li><a href="pages/profile.html"><span class="#"></span> Prijava</a></li>


            <li class="dropdown">
           <a class="dropdown-toggle" data-toggle="dropdown" href="#">...
             <span class="caret"></span>
           </a>
           <ul class="dropdown-menu">
             <li><a href="#">Vizija</a></li>
             <li><a href="#">Tim YUgologija</a></li>
             <li><a href="#">Pomo&#263;</a></li>
             <li><a href="#">Blog</a></li>
             <li><a href="#">Komentari</a></li>
             <li><a href="#">Novosti iz sveta filma</a></li>
           </ul>
         </li>

        </ul>
      </div>
    </div>
  </nav>


<div class="container text-center">


  <div class="row">
    <div class="container">
    <div class="row">
      <div class="col-sm-6">
        <div id="myCarousel" class="carousel slide" data-ride="carousel">


          <!-- Wrapper for slides -->
          <div class="carousel-inner" role="listbox">
            <div class="item active">
              <a href="filmovi/KoToTamoPeva.html">
              <img src="images_filmovi/KoToTamoPeva.jpg" alt="Ko to tamo peva"></a>
              <div class="carousel-caption">
              </div>
            </div>



          <div class="item">
            <a href="filmovi/LD_ZoranRadmilovic.html">
            <img src="images_filmovi/LD_ZoranRadmilovic.jpg" alt="Li&#269;nosti i Dogadjaji - Zoran Radmilovic"></a>
            <div class="carousel-caption">
              <p></p>
            </div>
          </div>

          <div class="item">
            <a href="register.html">
            <img src="images_filmovi/promocija.png" alt="promocija"></a>
            <div class="carousel-caption">
              <p><h4>Promocija - besplatna pretplata <br>mesec dana</h4></p>
            </div>
        </div>

          <div class="item">
            <a href="filmovi/SamacUBraku.html">
            <img src="images_filmovi/SamacUBraku.jpg" alt="Samac u braku"></a>
            <div class="carousel-caption">
              <p></p>
            </div>
          </div>

          <div class="item">
            <a href="filmovi/DervisISmrt.html">
            <img src="images_filmovi/DervisISmrt2.jpg" alt="Dervis i smrt"></a>
            <div class="carousel-caption">
              <p></p>
            </div>
          </div>

          <div class="item">
            <a href="filmovi/NestoIzmedju.html">
            <img src="images_filmovi/NestoIzmedju2.jpg" alt="Nesto izmedju"></a>
            <div class="carousel-caption">
              <p></p>
            </div>
          </div>

          <div class="item">
            <a href="register.html">
            <img src="images_filmovi/promocija.png" alt="promocija"></a>
            <div class="carousel-caption">
              <p><h4>Promocija - besplatna pretplata <br>mesec dana</h4></p>
            </div>
        </div>

          <div class="item">
            <a href="filmovi/LD_JovaJovanovicZmaj.html">
            <img src="images_filmovi/LD_JovaJovanovicZmaj.jpg" alt="Li&#269;nosti i Doga&#273;aji - Jova Jovanovic Zmaj"></a>
            <div class="carousel-caption">
              <p></p>
            </div>
          </div>

          <div class="item">
            <a href="filmovi/KrvavaBajka.html">
            <img src="images_filmovi/KrvavaBajka.jpg" alt="Krvava bajka"></a>
            <div class="carousel-caption">
              <p></p>
            </div>
          </div>

          <div class="item">
            <a href="filmovi/KnezevinaSrbija.html">
            <img src="images_filmovi/KnezevinaSrbija2.jpg" alt="Knezevina Srbija"></a>
            <div class="carousel-caption">
              <p></p>
            </div>
          </div>

          <div class="item">
            <a href="filmovi/CrveniMakovi.html">
            <img src="images_filmovi/CrveniMakovi.jpg" alt="Crveni makovi"></a>
            <div class="carousel-caption">
              <p></p>
            </div>
          </div>


<br>


<div class="wellFacebook">
          <div class="fb-like" data-href="http://www.yugologija.com" data-width="450" data-layout="standard" data-action="like" data-show-faces="false" data-share="true">
          facebook
          </div>
        </div>
    <div class="wellCosa">
      <div class="titleCosa">
            <a href="pages/CosinoCose.html">&#262;osino &#262;o&#353;e - Dragan Marinkovi&#263; pi&#353;e za vas &nbsp;&nbsp;&nbsp;>>> </a>
          </div>
    </div>

        </div>

        </div>
      </div>

    <div class="col-sm-3">

  <figure class="wp-caption">
        <a  href="filmovi/LD_ZoranRadmilovic.html">
        <img src="images_filmovi/LD_ZoranRadmilovic.jpg" class="img-responsive" style="width:100%" alt="Li&#269;nosti i dogadjaji - Zoran Radmilovic"></a>

        <figcaption class="wp-caption-text"><a href="filmovi/LD_ZoranRadmilovic.html">Li&#269;nosti i dogadjaji - Z. Radmilovi&#263;</a></figcaption>
      </figure>
      <p></p>
      </div>

<div class="col-sm-3">
  <div class="well">
    <p>

    Na&#353; novootvoreni &apos;online&apos; bioskop je namenjen  publici van Srbije
      i zemalja regiona. Potrebno je samo da se registrujete i uz mese&#269;nu
      &apos;kartu&apos; od $5.99 uplovite u svet kinematografije.

          </p>
</div>
</div>


<div class="col-sm-3">

  <figure class="wp-caption">
    <a  href="filmovi/CrveniMakovi.html">
    <img src="images_filmovi/CrveniMakovi.jpg" class="img-responsive" style="width:100%" alt="Crveni makovi"></a>

    <figcaption class="wp-caption-text"><a href="filmovi/CrveniMakovi.html">Crveni makovi</a></figcaption>
  </figure>
  <p></p>
</div>

<div class="col-sm-3">

  <figure class="wp-caption">

    <img src="images_filmovi/SamacUBraku_Trajler.jpg" id="myBtn" class="img-responsive" style="width:100%" alt="Samac u braku"></a>

    <figcaption class="wp-caption-text"><a href="#">Samac u braku </a></figcaption>
  </figure>
  <p></p>


  <!-- The Modal -->
  <div id="myModal" class="modal">

    <!-- Modal content -->
    <div class="modal-content">
      <span class="close">&times;</span>


<div class="player-wrapper">
<div id="player">
</div>
</div>


<script type="text/javascript">
  if (location.protocol === 'file:') {
    document.getElementById('webserver-warning').style.display = 'block';
  }

//var playerId = 'player';

  var initializedPlayers        = 0;
  var players                   = {
    'player'       : null
  };

  var config                    = {

    key:              '49252481-f419-4ad1-a781-fe80c98258e1',
    source: {
      dash:        "http://1745046703.rsc.cdn77.org/trajlers/SamacUBrakuTrajler/497855_4fea0230e04062b0e5c25568ec624482/497855.mpd",
      hls:         "http://1745046703.rsc.cdn77.org/trajlers/SamacUBrakuTrajler/497855_4fea0230e04062b0e5c25568ec624482/497855.m3u8",
      poster:      "http://www.yugologija.com/images_filmovi/SamacUBraku.jpg"
    },

    playback: {
      autoplay: true
    }

  };

  function playPause(type) {
    for (var prop in players) {
      if (players.hasOwnProperty(prop)) {
        if (type === 'play') {
          players[prop].play();
        } else if (type === 'pause') {
          players[prop].pause();
        }
      }
    }
  }

  function onPlay() {
    this.pause();
    this.removeEventHandler('onPlay', onPlay);
  }

  function onDownloadFinished(event) {
    if (event.url.indexOf('segment_1') >= 0) {
      if (++initializedPlayers === 1) {
        //document.getElementById('play').removeAttribute('disabled');
      //  document.getElementById('pause').removeAttribute('disabled');
      }
      this.removeEventHandler('onDownloadFinished', onDownloadFinished);
    }
  }


  (function init() {

    initializedPlayers = 0;

    var playerReady = function(player) {
      players[player.getFigure().parentNode.id] = player;
      if (player.isPlaying()) {
        player.pause();
      } else {
        player.addEventHandler('onPlay', onPlay);
      }
      player.addEventHandler('onDownloadFinished', onDownloadFinished);
      player.addEventHandler('onPlaybackFinished', function () {
        this.play();
      });
    };


    bitmovin.player('player').setup(config).then(playerReady);
  })();
</script>

</div>
</div>


<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {

    modal.style.display = "none"
    playPause('pause');
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</div>





<div class="col-sm-3">
    <div class="wellCosa">
        <div class="title">
        <a href="#">&#352;ta ka&#382;u na&#353;i korisnici: </a>
        </div>
      <div id="myCarousel" class="carousel slide text-center" data-ride="carousel">
          <div class="carousel-inner" role="listbox">
              <div class="item active">
                <p>Divno! - Milica</span></p>
                </div>
                <div class="item">
                  <p>WOW!!- Dragan Vasiljevi&#263;</p>
                  </div>
                  <div class="item">
                    <p>&#352;to ja volim maratonce! - Zoran</p>
                    </div>
                    <div class="item">
                      <p>I know the guys who run the website so I subscribed and I like the films with the subtitles - Eleanor D.</p>
                      </div>
                      <div class="item">
                        <p>Hvala vam na serijama - Klara</p>
                        </div>

          </div>
        </div>
      </div>
    <div class="col-sm-8">
      <img src="images/spacer.png" >
    </div>

      <div class="col-sm-4">
      <img src="images/PageArrow_v1.png" >
      </div>
    </div>

</div>

<div class="row">

  <div class="col-sm-4">
<a href="filmovi/DervisISmrt.html">
<img src="images_filmovi/DervisISmrt2.jpg" class="img-responsive" style="width:100%" alt="&#268;uvar pla&#382;e u zimskom periodu"></a>
    <figure class="wp-caption1">
      <figcaption class="wp-caption-text1"><a href="filmovi/DervisISmrt.html">Dervi&#353; i smrt</a></figcaption>
      </figure>
  </div>
  <div class="col-sm-4">

      <a  href="filmovi/SamacUBraku.html">
    <img src="images_filmovi/SamacUBraku.jpg" class="img-responsive" style="width:100%" alt="Samac u braku"></a>
<figure class="wp-caption1">
    <figcaption class="wp-caption-text1"><a href="filmovi/SamacUBraku.html">Samac u Braku - serija </a></figcaption>
    </figure>
    <p></p>
  </div>


  <div class="col-sm-4">

      <a  href="filmovi/NestoIzmedju.html">
    <img src="images_filmovi/NestoIzmedju2.jpg" class="img-responsive" style="width:100%" alt="Nesto Izmedju"></a>
<figure class="wp-caption1">
    <figcaption class="wp-caption-text1"><a href="filmovi/NestoIzmedju.html">Ne&#353;to izmedju</a></figcaption>
    </figure>
     <p></p>
  </div>
</div>

<div class="row">

  <div class="col-sm-4">

      <a  href="filmovi/KnezevinaSrbija.html">
    <img src="images_filmovi/KnezevinaSrbija2.jpg" class="img-responsive" style="width:100%" alt="Knezevina Srbija"></a>
<figure class="wp-caption1">
    <figcaption class="wp-caption-text1"><a href="filmovi/KnezevinaSrbija.html">Kne&#382;evina Srbija</a></figcaption>
    </figure>
    <p></p>
  </div>


  <div class="col-sm-4">

      <a  href="filmovi/KoToTamoPeva.html">
    <img src="images_filmovi/KoToTamoPeva.jpg" class="img-responsive" style="width:100%" alt="Ko to tamo peva"></a>
<figure class="wp-caption1">
    <figcaption class="wp-caption-text1"><a href="filmovi/KoToTamoPeva.html">Ko to tamo peva</a></figcaption>
    </figure>
    <p></p>
  </div>


  <div class="col-sm-4">

      <a  href="filmovi/LD_JovaJovanovicZmaj.html">
    <img src="images_filmovi/LD_JovaJovanovicZmaj.jpg" class="img-responsive" style="width:100%" alt="Jova Jovanovi&#263; Zmaj"></a>
<figure class="wp-caption1">
    <figcaption class="wp-caption-text1"><a href="filmovi/LD_JovaJovanovicZmaj.html">Licnosti i dogadjaji<br>Jova Jovanovi&#263; Zmaj</a></figcaption>
    </figure>    <p></p>
  </div>
</div>


<div class="row">

  <div class="col-sm-4">

      <a  href="filmovi/KrvavaBajka.html">

      <img src="images_filmovi/KrvavaBajka.jpg" class="img-responsive" style="width:100%" alt="Krvava bajka"></a>
<figure class="wp-caption1">
      <figcaption class="wp-caption-text1"><a href="filmovi/KrvavaBajka.html">Krvava Bajka</a></figcaption>
    </figure>
    <p></p>
  </div>

<div class="col-sm-4">

    <a  href="filmovi/repertoarApril.html">
    <img src="http://1745046703.rsc.cdn77.org/images_filmovi/promocija.png" class="img-responsive" style="width:100%" alt="repertoar mart 2017"></a>
<figure class="wp-caption1">
    <figcaption class="wp-caption-text1"><a href="filmovi/repertoarApril.html">Repertoar za <br>April 2017.</a></figcaption>
  </figure>
  <p></p>
</div>



</div>
  <hr>


<br><br>

<footer class="container-fluid text-center">
  <p>Copyright Yugologija 2017</p>
</footer>
<?php else: ?>

	<?php header('Location: http://www.yugologija.com/index.html'); ?>

<?php endif; ?>
</body>
</html>
