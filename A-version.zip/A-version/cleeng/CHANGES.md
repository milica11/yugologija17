3.5.1 (2016-07-13)
==================
* don't trigger notice when handling json-rpc 2.0 responses in correct format 

3.5.0 (2016-06-15)
==================
* allow enabling sandbox mode using `Cleeng_Api` constructor 

3.4.2 (2016-06-12)
==================
* extend EventOffer Api

3.4.1 (2016-05-05)
==================
* add "email" field to customer entity

3.4 (2016-04-27)
================
* remove deprecated method: trackOfferImpression

3.3.0 (2015-07-29)
==================
* add `toArray()` method on entity

3.2.2 (2015-07-28)
==================
* Add VOD offer entity

3.2.1 (2015-07-27)
==================
* Add event offer entity

3.2 (2015-05-12)
================

* automatically load Customer Token from the URL if not available in a cookie
* coupon campaign methods added
* split batch calls into multiple HTTP requests if there are too many of them
* change url for JS api endpoint
