<?php

$offerId = 'S554061791_GB';
// include PHP SDK
include_once('cleeng/cleeng_api.php');
$cleengApi = new Cleeng_Api();
?>

<html>
<head>
<script type='text/javascript' src='http://www.geolify.com/georedirect.php?id=23354'></script>
<script type="text/javascript">
    CleengApi.trackOfferImpression("<?php echo $offerId ?>");
    function cleengPurchase() {
  CleengApi.purchase("<?php echo $offerId ?>", function (result) {

      window.location.reload();
  });
    }
</script>
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-89022952-1', 'auto');
ga('send', 'pageview');

</script>
<script type="text/javascript" src="http://1018985591.rsc.cdn77.org/YUlive/bitmovin-player/bitmovinplayer.js"></script> </head>
  <body bgcolor="black">
    <?php

    // Check if visitor has access to protected content
    if ($cleengApi->isAccessGranted($offerId)): ?>

<center><br><br><br>
	<div id="player"></div>
</center>
    <script type="text/javascript">
    var conf = {
        key:       "49252481-f419-4ad1-a781-fe80c98258e1",

        source: {
          dash:        "http://1018985591.rsc.cdn77.org/YUlive/OpasniTrag/457181_9ec8ab63289df0517af904c3bb5e9dbc/mpds/457181.mpd",
          hls:         "http://1018985591.rsc.cdn77.org/YUlive/HLSenc/HLS_OpasnaTrag/462009_35544b32cdb265777ab57b26222be51f/m3u8s/462009.m3u8",
          poster:      "http://1018985591.rsc.cdn77.org/YUlive/images/OpasniTrag.jpg"

    },


    style : {
      width       : '75%',
      aspectratio : '16:9',
      controls    : true
    },




    drm: {
          widevine: {
            LA_URL: 'http://widevine-dash.ezdrm.com/proxy?pX=D25B71'
          },
          playready: {
            LA_URL: 'http://playready.ezdrm.com/cency/preauth.aspx?pX=CE3647'
          },

/*
          fairplay: {
            LA_URL: 'http://fps.ezdrm.com/api/licenses/CONTENT_ID',
            certificateURL: 'CERTIFICATE_URL',
            prepareContentId: function(contentId) {
              var uri = contentId;
              var uriParts = uri.split('://', 1);
              var protocol = uriParts[0].slice(-3);
              uriParts = uri.split(';', 2);
              contentId = uriParts.length > 1 ? uriParts[1] : '';
              return protocol.toLowerCase() == 'skd' ? contentId : '';
            },
*/
            prepareLicenseAsync: function(ckc) {
              return new Promise(function(resolve, reject) {
                var reader = new FileReader();
                reader.addEventListener('loadend', function() {
                  resolve(new Uint8Array(reader.result));
                });
                reader.addEventListener('error', function() {
                  reject(reader.error);
                });
                reader.readAsArrayBuffer(ckc);
              });
            },
            prepareMessage: function(event, session) {
              return new Blob([event.message], {type: 'application/octet-binary'});
            },
            headers: [{
              name: 'content-type',
              value: 'application/octet-stream'
            }],
            useUint16InitData: true,
            licenseResponseType: 'blob'
          }

       };



//  level : bitmovin.player.LOGLEVEL.DEBUG,

//  delay: 30000



    var player = bitmovin.player("player");

    player.setup(conf).then(function(value) {
        // Success
        console.log("Successfully created bitmovin player instance");
    }, function(reason) {
        // Error!
        console.log("Error while creating bitmovin player instance");
    });
</script>

  <?php else: ?>

  	<?php header('Location: http://www.yugologija.com/registerNew.html'); ?>

  <?php endif; ?>
  </body>
  </html>
