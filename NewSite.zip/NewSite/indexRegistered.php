
  <?php
  /**
   * Cleeng API Example 1 - How to protect your content
   * you can find tutorial 1 here: http://cleeng.com/open/Tutorials/01_Starting_with_Cleeng_PHP_SDK
   * =====================================================================
   * This file should be opened in browser, probably:
   * your-site.com/01_Getting_started_with_Cleeng/purchase.php
   * =====================================================================
   * Remember, if you want to test payment process, you have to work on sandbox.
   * Check how to work with sandbox in Tutorial 3 : http://cleeng.com/open/Tutorials/03_Sandbox_testing
   * =====================================================================
   */
  // set the ID of the offer you want to sell
  $offerId = 'S243934395_GB'; //default offer for cleeng.com
  // include PHP SDK
  include_once('cleeng/cleeng_api.php');
  $cleengApi = new Cleeng_Api();
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <script type="text/javascript">
  	    CleengApi.trackOfferImpression("<?php echo $offerId ?>");
  	    function cleengPurchase() {
  		CleengApi.purchase("<?php echo $offerId ?>", function (result) {
  		    // reload page after purchase to reveal protected ite
  		    // improve the user experience - learn how to load with AJAX in tutorial 2
  		    window.location.reload();
  		});
  	    }
  	</script>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <style>
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }


    .title a {
        color: #888888;
        text-decoration: none;
        font-size: 30px
    }

    .carousel-inner img {
      width: 100%; /* Set width to 100% */
      min-height: 200px;
    }

    /* Hide the carousel text when the screen is less than 600 pixels wide */
    @media (max-width: 600px) {
      .carousel-caption {
        display: none;
      }
    }
  </style>
</head>
<body>
  <?php

  // Check if visitor has access to protected content
  if ($cleengApi->isAccessGranted($offerId)): ?>





<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">YUgologija</a>
      <img src="red_pixel.png" height="40px" width="2px">
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">

      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="g#"></span> Prijava</a></li>
          <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Prijava</a></li>
            <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Prijava</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Prijava</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">
<div class="row">
  <div class="col-sm-8">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>

      </ol>

      <!-- Wrapper for slides -->
      <div class="carousel-inner" role="listbox">
        <div class="#">
          <img src="images_filmovi/Maratonci.jpg" alt="Maratonci">
          <a href="player/Maratonci.html"
          <div class="carousel-caption">
            <h3>Maratonci trce pocasni krug</h3>
            <p>Gledajte sada</p>
          </div>
        </div>



      <!-- Left and right controls -->
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="#" aria-hidden="true"></span>
        <span class="#"></span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="#" aria-hidden="true"></span>
        <span class="#"></span>
      </a>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="well">
      <p>
        <div class="title">
    <a href="maratonci.html">MARATONCI</a><br></div>
    Pri&#269;a se odvija u vremenu izmedju dva rata. U porodici Topalovi&#263; , koju &#269;ini
    pet generacija mu&#353;karaca - najmladji ima 25, a najstariji 120 godina, dolazi do velikih sukoba
    jer mladi potomak ne &#382;eli da se bavi pogrebni&#269;kim zanatom.<br><br>


    U filmu, &#269;iji je scenarista <a href="glumci/DusanKovacevic.html" style="color:orange; text-decoration: none;">Du&#353;an Kova&#269;evi&#263;</a>, igraju <a href="glumci/MicaTomic.html" style="color:orange; text-decoration: none;">Mi&#263;a Tomi&#263;</a>, <a href="glumci/MijaAleksic.html" style="color:orange; text-decoration: none;">Mija Aleksi&#263;</a>, <a href="glumci/PavleVuisic.html" style="color:orange; text-decoration: none;">Pavle Vuisi&#263;</a>,<a href="glumci/BataStojkovic.html" style="color:orange; text-decoration: none;"> Danilo Bata Stojkovi&#263;</a>, <a href="glumci/BogdanDiklic.html" style="color:orange; text-decoration: none;">Bogdan Dikli&#263;</a>, <a href="glumci/ZoranRadmilovic.html" style="color:orange; text-decoration: none;">Zoran Radmilovi&#263;</a>, <a href="glumci/BoraTodorovic.html" style="color:orange; text-decoration: none;">Bora Todorovi&#263;</a>, <a href="glumci/JelisavetaSablic.html" style="color:orange; text-decoration: none;">Jelisaveta Sabli&#263;</a>.

    <br><br>



      </p>
    </div>


  </div>
</div>
<hr>
</div>

<div class="container text-center">
<!-- row 1 -->
  <br>
  <div class="row">
    <div class="col-sm-4">
      <a href="filmovi/CuvarPlaze.html">
      <img src="images_filmovi/CuvarPlaze.jpg" class="img-responsive" style="width:100%" alt="Image"></a>
      <div class="carousel-caption-titles">
        &#268;uvar pla&#382;e
        <p></p>
      </div>
      <p></p>
    </div>

    <div class="col-sm-4">
      <img src="images_filmovi/BranioSamMladuBosnu.jpg" class="img-responsive" style="width:100%" alt="Image">
      <div class="carousel-caption-titles">
        Branio Sam Mladu Bosnu
        <p></p>
      </div>
      <p></p>
    </div>

    <div class="col-sm-4">
      <img src="images_filmovi/MirisPoljskogCveca.jpg" class="img-responsive" style="width:100%" alt="Image">
      <div class="carousel-caption-titles">
        Miris poljskog cve&#263;a
        <p></p>
      </div>
      <p></p>
  </div>
    </div>

    <!-- row 2 -->

    <br>
    <div class="row">
      <div class="col-sm-4">
        <img src="images_filmovi/GdeJeNadja.jpg" class="img-responsive" style="width:100%" alt="Image">
        <div class="carousel-caption-titles">
          Gde je Nadja
          <p></p>
        </div>
        <p></p>
      </div>

      <div class="col-sm-4">
        <img src="images_filmovi/OpasniTrag.jpg" class="img-responsive" style="width:100%" alt="Image">
        <div class="carousel-caption-titles">
          Opasni trag
          <p></p>
        </div>
        <p></p>
      </div>

      <div class="col-sm-4">
        <img src="images_filmovi/VojvodaZivojinMisic.jpg" class="img-responsive" style="width:100%" alt="Image">
        <div class="carousel-caption-titles">
          Li&#269;nosti i Dogadjaji<br>
          <h5>Vojvoda &#381;ivojin Misi&#263;</h5>
        </div>
        <p></p>
    </div>
      </div>





<!-- row 3 -->
<br>
<div class="row">
  <div class="col-sm-4">
    <img src="images_filmovi/DobaDundjerskih.jpg" class="img-responsive" style="width:100%" alt="Image">
    <div class="carousel-caption-titles">
      Doba Dundjerskih

    </div>
    <p></p>
  </div>

  <div class="col-sm-4">
    <img src="images_filmovi/BoraTodorovicLD.jpg" class="img-responsive" style="width:100%" alt="Image">
    <div class="carousel-caption-titles">
      Li&#269;nosti i Dogadjaji<br>
      <h5>Bora Todorovi&#263;</h5>
    </div>
    <p></p>
  </div>

  <div class="col-sm-4">
    <img src="images_filmovi/AirSrbia.jpg" class="img-responsive" style="width:100%" alt="Image">
    <div class="carousel-caption-titles">

    </div>
    <p></p>
</div>
  </div>



<footer class="container-fluid text-center">
  <p>Copyright Yugologija 2017</p>
</footer>
<?php else: ?>

	<?php header('Location: http://www.videologija.com/NewSite/registerNew.html'); ?>

<?php endif; ?>
</body>
</html>
