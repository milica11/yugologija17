
  <?php

  $offerId = 'S243934395_GB';
  // include PHP SDK
  include_once('cleeng/cleeng_api.php');
  $cleengApi = new Cleeng_Api();
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <script type="text/javascript">
  	    CleengApi.trackOfferImpression("<?php echo $offerId ?>");
  	    function cleengPurchase() {
  		CleengApi.purchase("<?php echo $offerId ?>", function (result) {

  		    window.location.reload();
  		});
  	    }
  	</script>
  <title>Doma&#263;i filmovi online</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <style>
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }


    .title a {
        color: #888888;
        text-decoration: none;
        font-size: 30px
    }

    .carousel-inner img {
      width: 100%; /* Set width to 100% */
      min-height: 200px;
    }

    /* Hide the carousel text when the screen is less than 600 pixels wide */
    @media (max-width: 600px) {
      .carousel-caption {
        display: none;
      }
    }
  </style>
</head>
<body>
  <?php

  // Check if visitor has access to protected content
  if ($cleengApi->isAccessGranted($offerId)): ?>


<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">YUgologija</a>
      <img src="red_pixel.png" height="40px" width="2px">
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">

      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="pages/profile.html"><span class="#"></span> Va&#353; profil</a></li>
          <li><a href="pages/zanimljivosti.html"><span class="#"></span> Zanimljivosti</a></li>
            <li><a href="pages/komentari.html"><span class="#"></span> Komentari</a></li>
              <li><a href="pages/kviz.html"><span class="#"></span> Kviz</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">
<div class="row">
  <div class="col-sm-8">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
         <li data-target="#myCarousel" data-slide-to="1"></li>

      </ol>

      <!-- Wrapper for slides -->
      <div class="carousel-inner" role="listbox">
        <div class="item active">
          <img src="images_filmovi/Maratonci.jpg" alt="Image">
          <div class="carousel-caption">
            <h3>Maratonci tr&#269;e po&#269;asan krug</h3>
            <p><a href="player/maratonci.php">Gledajte sada</a></p>
          </div>
        </div>

        <div class="item">
          <img src="images_filmovi/Maratonci1.png" alt="Image">
          <div class="carousel-caption">
            <h3>Maratonci tr&#269;e po&#269;asan krug</h3>
          <p><a href="player/maratonci.php">Gledajte sada</a></p>
          </div>
        </div>
      </div>


    </div>
  </div>




  <div class="col-sm-4">
    <div class="well">
      <p>
        <div class="title">
    <a href="#">Ove nedelje</a><br>
  </div><p>
    O Yugologiji itd i sta dolazi na red inace ce ovde da se nalaze obavestenja
    i slicne novosti i highlights<br><br>
      </p>
    </div>

    <div class="well">
      <p>
        <div class="title">
    <a href="filmovi/Maratonci.html">Film nedelje - MARATONCI</a><br>
    </div>
    Pri&#269;a se odvija u vremenu izmedju dva rata. U porodici Topalovi&#263; , koju &#269;ini
    pet generacija mu&#353;karaca - najmladji ima 25, a najstariji 120 godina, dolazi do velikih sukoba
    jer mladi potomak ne &#382;eli da se bavi pogrebni&#269;kim zanatom.<br><br>


    U filmu, &#269;iji je scenarista <a href="glumci/DusanKovacevic.html" style="color:orange; text-decoration: none;">Du&#353;an Kova&#269;evi&#263;</a>, igraju <a href="glumci/MicaTomic.html" style="color:orange; text-decoration: none;">Mi&#263;a Tomi&#263;</a>, <a href="glumci/MijaAleksic.html" style="color:orange; text-decoration: none;">Mija Aleksi&#263;</a>, <a href="glumci/PavleVuisic.html" style="color:orange; text-decoration: none;">Pavle Vuisi&#263;</a>,<a href="glumci/BataStojkovic.html" style="color:orange; text-decoration: none;"> Danilo Bata Stojkovi&#263;</a>, <a href="glumci/BogdanDiklic.html" style="color:orange; text-decoration: none;">Bogdan Dikli&#263;</a>, <a href="glumci/ZoranRadmilovic.html" style="color:orange; text-decoration: none;">Zoran Radmilovi&#263;</a>, <a href="glumci/BoraTodorovic.html" style="color:orange; text-decoration: none;">Bora Todorovi&#263;</a>, <a href="glumci/JelisavetaSablic.html" style="color:orange; text-decoration: none;">Jelisaveta Sabli&#263;</a>.

    <br><br>



      </p>
    </div>
  </div>
</div>
<hr>
</div>

<div class="container text-center">
<!-- row 1 -->
  <br>
  <div class="row">
    <div class="col-sm-4">
      <a href="filmovi/CuvarPlaze.html">
      <img src="images_filmovi/CuvarPlaze.jpg" class="img-responsive" style="width:100%" alt="Image"></a>
      <div class="carousel-caption-titles">
        &#268;uvar pla&#382;e

      </div>
      <p></p>
    </div>

    <div class="col-sm-4">
      <a href="filmovi/BranioSamMladuBosnu.html">
      <img src="images_filmovi/BranioSamMladuBosnu.jpg" class="img-responsive" style="width:100%" alt="Image"></a>
      <div class="carousel-caption-titles">
        Branio Sam Mladu Bosnu
        <h5>Serija sa 12 epizoda</h5>
      </div>

    </div>

    <div class="col-sm-4">
      <a href="filmovi/MirisPoljskogCveca.html">
      <img src="images_filmovi/MirisPoljskogCveca.jpg" class="img-responsive" style="width:100%" alt="Image"></a>
      <div class="carousel-caption-titles">
        Miris poljskog cve&#263;a
        <p></p>
      </div>

  </div>
    </div>

    <!-- row 2 -->

    <br>
    <div class="row">
      <div class="col-sm-4">
        <a href="filmovi/GdeJeNadja.html">
        <img src="images_filmovi/GdeJeNadja.jpg" class="img-responsive" style="width:100%" alt="Image"></a>
        <div class="carousel-caption-titles">
          Gde je Nadja
          <p></p>
        </div>

      </div>

      <div class="col-sm-4">
        <a href="filmovi/OpasniTrag.html">
        <img src="images_filmovi/OpasniTrag.jpg" class="img-responsive" style="width:100%" alt="Image"></a>
        <div class="carousel-caption-titles">
          Opasni trag
          <p></p>
        </div>

      </div>

      <div class="col-sm-4">
        <a href="filmovi/LD_ZivojinMisic.html">
        <img src="images_filmovi/VojvodaZivojinMisic.jpg" class="img-responsive" style="width:100%" alt="Image"></a>
        <div class="carousel-caption-titles">
          Li&#269;nosti i Dogadjaji<br>
          <h5>Vojvoda &#381;ivojin Misi&#263;</h5>
        </div>

    </div>
      </div>





<!-- row 3 -->
<br>
<div class="row">
  <div class="col-sm-4">
    <a href="filmovi/DobaDundjerskih.html">
    <img src="images_filmovi/DobaDundjerskih.jpg" class="img-responsive" style="width:100%" alt="Image"></a>
    <div class="carousel-caption-titles">
      Doba Dundjerskih

    </div>

  </div>

  <div class="col-sm-4">
    <a href="filmovi/LD_BoraTodorovic.html">
    <img src="images_filmovi/BoraTodorovicLD.jpg" class="img-responsive" style="width:100%" alt="Image"></a>
    <div class="carousel-caption-titles">
      Li&#269;nosti i Dogadjaji<br>
      <h5>Bora Todorovi&#263;</h5>
    </div>

  </div>

  <div class="col-sm-4">
    <img src="images/logoYU.png" class="img-responsive" style="width:100%" alt="Image">
    <div class="carousel-caption-titles">

    </div>

</div>
  </div>



<footer class="container-fluid text-center">
  <p>Copyright Yugologija 2017</p>
</footer>
<?php else: ?>

	<?php header('Location: http://www.videologija.com/registerNew.html'); ?>

<?php endif; ?>
</body>
</html>
