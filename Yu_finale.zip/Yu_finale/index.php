<?php

// set the ID of the offer you want to sell
$offerId = 'S240658261_GB'; //default offer for cleeng.com
// include PHP SDK
include_once('cleeng/cleeng_api.php');



$cleengApi = new Cleeng_Api();
?>
<html>
<head>
	<script type="text/javascript" src="http://cleeng.com/js-api/3.0/api.js"></script>
	<script type="text/javascript">
	    CleengApi.trackOfferImpression("<?php echo $offerId ?>");
	    function cleengPurchase() {
		CleengApi.purchase("<?php echo $offerId ?>", function (result) {
		    // reload page after purchase to reveal protected item
		    // improve the user experience - learn how to load with AJAX in tutorial 2
		    //window.location.reload();
		    //window.location.assign()
		});
	    }
	</script>

	<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-89022952-1', 'auto');
  ga('send', 'pageview');

</script>
</head>
<body>


<?php

// Check if visitor has access to protected content
if ($cleengApi->isAccessGranted($offerId)): ?>
<?php header('Location: http://www.yugologija.com/indexRegistered.php'); ?>



<?php else: ?>

	<?php header('Location: http://www.yugologija.com/registerNew.html'); ?>

<?php endif; ?>



</body>
</html>
